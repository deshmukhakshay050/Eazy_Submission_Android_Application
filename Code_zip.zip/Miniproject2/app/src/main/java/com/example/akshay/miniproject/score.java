package com.example.akshay.miniproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.akshay.miniproject.R;
import com.example.akshay.miniproject.SignInInfo;
import com.example.akshay.miniproject.webview;

/**
 * Created by akshay on 5/10/17.
 */
 public class score extends AppCompatActivity
{

    TextView textView;
    SharedPreferences sharedpreferences;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.score);

        textView=(TextView)findViewById(R.id.score);
        sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);
        String score=sharedpreferences.getString("score","");
        textView.setText( score);
    }

    public void onBackPressed()
    {
        Intent intent = new Intent(score.this, SignInInfo.class);
        startActivity(intent);

    }
    public void onPause()
    {
        super.onPause();

        sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();

        editor.putString("close","false");
        editor.putString("akshay","akshay");
        editor.commit();

    }
}
