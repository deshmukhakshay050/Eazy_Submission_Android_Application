package com.example.akshay.miniproject;

import android.app.AlertDialog;
/*import android.app.IntentService;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.content.Intent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import static android.support.v4.content.ContextCompat.startActivity;

/**
 * Created by akshay on 27/8/17.
 */
/*
public class Background extends AsyncTask<String,String,String>
{
    Context ctx;
    AlertDialog d;

    ProgressBar pb;


    public Background(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
    }
    @Override
    protected void onPreExecute() {
       // d=new AlertDialog.Builder(ctx).create();
        //d.setTitle("Login Information...");

        super.onPreExecute();
    }

    protected void onPostExecute(String  resultd) {
       ;
        if(resultd.equals("success"))
        {
            Intent intent = new Intent(ctx, SignInInfo.class);
        {
            d.setMessage("Login failed:Check for valid username and password!");
            d.show();
        }


    }
    protected String doInBackground(String... params)
    {
        String method=params[0];
        String login_url="http://192.168.1.7/login.php";
        String roll=params[1];
        String pass=params[2];
        String response="";
        try {
            URL url=new URL(login_url);
            HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream=httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter=new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
            String data= URLEncoder.encode("roll","UTF-8")+"="+URLEncoder.encode(roll,"UTF-8")+"&"+
                    URLEncoder.encode("pass","UTF-8")+"="+URLEncoder.encode(pass,"UTF-8")+"&";
            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();

            InputStream inputStream=httpURLConnection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));

            String line="";

            while((line=bufferedReader.readLine())!=null)
            {
                response=response+line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;

    }
}
*/