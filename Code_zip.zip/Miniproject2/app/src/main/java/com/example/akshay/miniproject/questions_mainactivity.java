package com.example.akshay.miniproject;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by akshay on 24/9/17.
 */
public class questions_mainactivity extends AppCompatActivity
{

    SharedPreferences sharedpreferences;
    String roll="";
    String div="";
    String subject="";
    String assignmentno="";
    String url="";

    String a[];
    String answer[];
    Toolbar toolbar;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    int cnt=0;



    String address = "http://192.168.1.100/quest.php";


    public RecyclerView recyclerView;
    public GridLayoutManager gridLayoutManager;
    public CustomAdapter adapter;
    public List<Mydata> data_list;

    Button b;


    @Override


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.questions_mainactivity);

        a=new String[20];
        answer=new String[20];
        toolbar=(Toolbar)findViewById(R.id.timer);
        final TextView textView=(TextView)findViewById(R.id.toolbarTextView);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Questions");
        sharedpreferences=getSharedPreferences("info", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();


        editor.commit();


        Intent stickyService = new Intent(questions_mainactivity.this, service.class);
        startService(stickyService);
        String close=sharedpreferences.getString("close","");
        editor.putString("clicked","false");
        editor.commit();





        //navigation part

        CountDownTimer countDownTimer= new CountDownTimer(100000, 1000) {
            public void onTick(long millisUntilFinished) {
                textView.setText("Ends in:- " + convert(millisUntilFinished/1000));
            }

            public void onFinish() {
                sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);
                String clicked = sharedpreferences.getString("clicked", "");
                if (clicked.equals("true") == false) {
                    int cnt = 0;
                    Log.w("A" + System.currentTimeMillis(), "B" + 2000);
                    textView.setText("Submission done!!");
                    a = adapter.a();
                    answer = adapter.ans();
                    int size = adapter.getItemCount();
                    for (int i = 1; i <= size; i++) {
                        if (a[i].equals(answer[i]) == true) {
                            cnt++;
                        }
                    }
                    String score = String.valueOf(cnt);

                    String url = "http://192.168.1.100/statusupdate.php";
                    SharedPreferences sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);

                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("score", score);
                    editor.putString("close", "false");
                    editor.commit();
                    String roll = (sharedpreferences.getString("roll", ""));
                    String div = sharedpreferences.getString("division", "");
                    String subject = sharedpreferences.getString("subject", "");
                    String assignmentno = sharedpreferences.getString("assignmentno", "");
                    url = url + "?subject=" + subject + "&assignmentno=" + assignmentno + "&rollno=" + roll;


                    url = url + "?subject=" + subject + "&assignmentno=" + assignmentno + "&rollno=" + roll + "&marks=" + cnt;
                    StringRequest stringRequest = new StringRequest(url, new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            // showJSON1(response);
                        }
                    },
                            new com.android.volley.Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(questions_mainactivity.this, error.getMessage().toString(), Toast.LENGTH_LONG).show();
                                }
                            });

                    RequestQueue requestQueue = Volley.newRequestQueue(questions_mainactivity.this);
                    requestQueue.add(stringRequest);

                    Intent i=new Intent(questions_mainactivity.this,score.class);
                    startActivity(i);


                }
            }
        }.start();


        SharedPreferences shared = getSharedPreferences("Miniproject", MODE_PRIVATE);

        String roll = (shared.getString("roll", ""));








        sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);
        roll =( sharedpreferences.getString("roll", ""));
        div=sharedpreferences.getString("division", "")    ;
        subject=sharedpreferences.getString("subject", "");
        assignmentno=sharedpreferences.getString("assignmentno","");
        url = address+"?subject="+subject+"&assignmentno="+assignmentno+"&rollno="+roll;

        //b=(Button)findViewById(R.id.submit);



        recyclerView=(RecyclerView)findViewById(R.id.recycler_view);


        data_list=new ArrayList<>();
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        adapter=new CustomAdapter(this,data_list);
        recyclerView.setAdapter(adapter);



        load();


    }

    public void load()
    {

       AsyncTask<Void, Void, Void> task= new AsyncTask<Void, Void, Void>() {
           @Override
           protected Void doInBackground(Void... voids) {

               OkHttpClient client=new OkHttpClient();
               Request request=new Request.Builder().url(url).addHeader("subject",subject).addHeader("assignmentno",assignmentno).addHeader("rollno",roll).build();




               try {
                   Response response=client.newCall(request).execute();
                   JSONArray array=new JSONArray(response.body().string());
                   int len=array.length();
                   for(int i=0;i<array.length();i++) {
                       JSONObject object = array.getJSONObject(i);

                       Mydata mydata = new Mydata(object.getString("questions"), object.getString("a"), object.getString("b"), object.getString("c"), object.getString("d"), object.getString("ans"));
                       data_list.add(mydata);

                   }
               } catch (IOException e) {
                   e.printStackTrace();
               } catch (JSONException e) {
                   e.printStackTrace();
               }


               return null;
           }

           protected  void onPostExecute(Void avoid)
           {
            adapter.notifyDataSetChanged();

           }

       };
        task.execute();


    }
    public void onBackPressed()
    {
        Toast.makeText(
                questions_mainactivity.this,
                "You must attempt the questions!!",
                Toast.LENGTH_LONG
        ).show();

    }

    public void clicked(View view)
    {
        int cnt=0;
        a=adapter.a();
        answer=adapter.ans();
        int size=adapter.getItemCount();
        for(int i=1;i<=size;i++)
        {
            if(a[i].equals(answer[i])==true)
            {
                cnt++;
            }
        }

        Toast.makeText(
                questions_mainactivity.this,
                "Your score is "+cnt,

                Toast.LENGTH_LONG
        ).show();
    }
    private static String convert(long longmilli)
    {
        long s=longmilli%60;
        long m=(longmilli/60)%60;
        long h=(longmilli/(3600))%24;
        return String.format("%02dh:%02dm:%02ds",h,m,s);

    }
    protected void onStop() {
        super.onStop();
        if(isFinishing()==true)
        {
            Log.w("A" + System.currentTimeMillis(), "finished");

        }
        else {

        }
}
    public void onPause()
    {
    super.onPause();
        a = adapter.a();
        answer = adapter.ans();
        int size = adapter.getItemCount();
        for (int i = 1; i <= size; i++) {
            if (a[i].equals(answer[i]) == true) {
                cnt++;
            }
        }
        String score=String.valueOf(cnt);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString("score",score);
        editor.putString("close","true");
        editor.putString("akshay","akshay");
        editor.commit();

    }
    public int getcnt()
    {
        return cnt;
    }
    public void onDestroy()
    {
        super.onDestroy();
        Log.w("A"+System.currentTimeMillis(),"B"+"on destroy alled");
    }



}
