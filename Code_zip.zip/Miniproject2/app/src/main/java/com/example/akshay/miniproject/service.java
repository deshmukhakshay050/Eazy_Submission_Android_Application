package com.example.akshay.miniproject;

import android.app.IntentService;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

/**
 * Created by akshay on 6/10/17.
 */
public class service extends Service
{

    @Nullable
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Nullable
    @Override

    public IBinder onBind(Intent intent) {
        return null;
    }




    public void onTaskRemoved(Intent rootIntent) {

        Log.d("onTaskRemoved called","on task removed called");
        super.onTaskRemoved(rootIntent);


        Log.w("A" + System.currentTimeMillis(), "on task removed alled");

        int cnt = 0;
        Log.w("A" + System.currentTimeMillis(), "B" + 2000);

        questions_mainactivity questions_mainactivity=new questions_mainactivity();
        questions_mainactivity.getcnt();
        String score = String.valueOf(cnt);
        String url = "http://192.168.1.100/statusupdate.php";
        SharedPreferences sharedpreferences;
        sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);

        String roll = (sharedpreferences.getString("roll", ""));
        String div = sharedpreferences.getString("division", "");
        String subject = sharedpreferences.getString("subject", "");
        String assignmentno = sharedpreferences.getString("assignmentno", "");
        url = url + "?subject=" + subject + "&assignmentno=" + assignmentno + "&rollno=" + roll;



        url = url + "?subject=" + subject + "&assignmentno=" + assignmentno + "&rollno=" + roll + "&marks=" + cnt;
        StringRequest stringRequest = new StringRequest(url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                // showJSON1(response);
            }
        },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(service.this, error.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(service.this);
        requestQueue.add(stringRequest);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        String close=sharedpreferences.getString("close","");
        editor.putString("close", "true");
        editor.commit();
        this.stopSelf();
    }
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("tag", "onStartCommand");
        return START_STICKY;
    }
    public void onDestroy() {
        super.onDestroy();
        Log.d("ClearFromRecentService", "Service Destroyed");
    }
}
