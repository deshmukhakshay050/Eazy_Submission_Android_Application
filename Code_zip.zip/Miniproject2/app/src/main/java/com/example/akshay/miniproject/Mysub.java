package com.example.akshay.miniproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.toolkit.SimpleTableHeaderAdapter;

/**
 * Created by akshay on 9/10/17.
 */
public class Mysub extends AppCompatActivity
{
    TableView<String[]> tb;
    TableHelper tableHelper;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub);


        tb = (TableView<String[]>) findViewById(R.id.tableview);
        tb.setColumnCount(7);

        tableHelper=new TableHelper(this);

        tb.setHeaderBackgroundColor(Color.parseColor("#2ecc71"));
        tb.setHeaderAdapter(new SimpleTableHeaderAdapter(this, tableHelper.getSpaceProbeHeaders()));

        new MySQLClient(Mysub.this).retrieve(tb);


    }
    public void onBackPressed()
    {

                Intent i=new Intent(Mysub.this,SignInInfo.class);
                startActivity(i);
                finish();

    }
}
