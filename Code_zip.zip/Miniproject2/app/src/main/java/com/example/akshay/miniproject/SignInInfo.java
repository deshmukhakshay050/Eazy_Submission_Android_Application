package com.example.akshay.miniproject;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.transition.ActionBarTransition;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Field;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SignInInfo extends AppCompatActivity {


    Context ctx;
    Spinner sp1,sp2,sp3;
    ArrayAdapter<CharSequence> a1,a2,a3;
    Toolbar toolbar;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    TextView textView;;
    String subject1="";
    String assignmentno1="";
    String rollno1="";
    String url = "http://192.168.1.100/status.php";
    String status="";


    SharedPreferences sharedpreferences;


    public SignInInfo(Context ctx)
    {
        this.ctx = ctx;
    }
    public SignInInfo()
    {

    }

    
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aditya_signin);
        sp1=(Spinner)findViewById(R.id.spinner);
        sp2=(Spinner)findViewById(R.id.spinner2);
        sp3=(Spinner)findViewById(R.id.spinner3);
        sp1.setDropDownWidth(300);
        sp2.setDropDownWidth(300);
        sp3.setDropDownWidth(300);


        sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);



        Field popup = null;
        try {
            popup = Spinner.class.getDeclaredField("mPopup");
        } catch (NoSuchFieldException e) {                                  //spinner part
            e.printStackTrace();
        }
        popup.setAccessible(true);


        android.widget.ListPopupWindow popupWindow = null;
        try {
            popupWindow = (android.widget.ListPopupWindow) popup.get(sp3);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        popupWindow.setHeight(500);




        SharedPreferences shared = getSharedPreferences("Miniproject", MODE_PRIVATE);

        String roll = (shared.getString("roll", ""));
        rollno1=roll;
        char a= roll.charAt(0);
        if(a=='2')
        {
            a1=ArrayAdapter.createFromResource(this,R.array.divse,android.R.layout.simple_spinner_item);
            a1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp1.setAdapter(a1);

            a2=ArrayAdapter.createFromResource(this,R.array.subjectse,android.R.layout.simple_spinner_item);
            a2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp2.setAdapter(a2);


            a3=ArrayAdapter.createFromResource(this,R.array.assignment,android.R.layout.simple_spinner_item);
            a3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp3.setAdapter(a3);
        }
        else
        {

            a1=ArrayAdapter.createFromResource(this,R.array.divte,android.R.layout.simple_spinner_item);
            a1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp1.setAdapter(a1);

            a2=ArrayAdapter.createFromResource(this,R.array.subjectte,android.R.layout.simple_spinner_item);
            a2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp2.setAdapter(a2);


            a3=ArrayAdapter.createFromResource(this,R.array.assignment,android.R.layout.simple_spinner_item);
            a3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp3.setAdapter(a3);
        }


        final SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString("roll", roll);

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String div=sp1.getSelectedItem().toString();
                editor.putString("division",String.valueOf(div));

                editor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String subject=sp2.getSelectedItem().toString();
                subject1=subject;
                editor.putString("subject", String.valueOf(subject));
                editor.commit();
            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String assignmentno=sp3.getSelectedItem().toString();
                assignmentno1=assignmentno;
                editor.putString("assignmentno",String.valueOf(assignmentno));
                editor.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });





        NavigationView navigationView=(NavigationView)findViewById(R.id.navigation_view);
        View view=navigationView.inflateHeaderView(R.layout.navigation_drawer_header);






        toolbar=(Toolbar)findViewById(R.id.toolbar);
        toolbar.bringToFront();
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Home");
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        textView=(TextView)view.findViewById(R.id.textview10);
        textView.setText(roll);




        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener()
        {

            @Override
            public boolean onNavigationItemSelected(MenuItem item) {

                Intent intent;
                switch (item.getItemId()) {

                    case R.id.subjects: {
                       intent=new Intent(SignInInfo.this,SignInInfo.class);
                       // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        //finish(); // destroy current activity..
                        startActivity(intent); // starts new activity;
                        break;
                    }
                    case R.id.logout: {
                        SharedPreferences shared = getSharedPreferences("Miniproject", MODE_PRIVATE);

                        String bool=shared.getString("bool","");
                        bool="false";
                        SharedPreferences.Editor editor = shared.edit();
                        editor.putString("bool",bool);
                        editor.commit();




                        intent = new Intent(SignInInfo.this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        finish(); // destroy current activity..
                        startActivity(intent); // starts new activity
                        break;
                    }
                    case R.id.assigninfo: {
                        intent = new Intent(SignInInfo.this, Mysub.class);
                        startActivity(intent);
                    //    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                      //  intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                       // finish(); // destroy current activity..
                        // starts new activity;
                        break;

                    }
                    case R.id.settings:
                    {
                    }

                }


                return false;
            }
        });

    }
    public void onBackPressed()
    {
        SharedPreferences shared = getSharedPreferences("Miniproject", MODE_PRIVATE);

        String bool;
        bool="close";
        SharedPreferences.Editor editor = shared.edit();
        editor.putString("bool",bool);
        editor.commit();
        finish();
    }

    protected void onPostCreate(Bundle savesInstanceState)
    {
        super.onPostCreate(savesInstanceState);
        actionBarDrawerToggle.syncState();

    }

    public void clicked(View view)
    {
        url =url+"?subject="+subject1+"&assignmentno="+assignmentno1+"&rollno="+rollno1;
        StringRequest stringRequest = new StringRequest(url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                showJSON1(response);
            }
        },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SignInInfo.this,error.getMessage().toString(),Toast.LENGTH_LONG).show();
                    }
                });

        com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    private void showJSON1(String response){
        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray result = jsonObject.getJSONArray("result");
            JSONObject collegeData = result.getJSONObject(0);
            status=collegeData.getString("STATUS");
            if(!status.equals("N"))
            {
                Toast.makeText(
                        SignInInfo.this,
                        "Assignment Already Submitted!!",
                        Toast.LENGTH_SHORT
                ).show();
            }
            else
            {
                Intent intent = new Intent(SignInInfo.this, webview.class);
                startActivity(intent);
            }
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

}
