package com.example.akshay.miniproject;

/**
 * Created by akshay on 9/10/17.
 */
public class Spacecraft
{

    private String subject;
    private String A1;
    private String A2;
    private String A3;
    private String A4;
    private String A5;
    private  String A6;

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setA6(String a6) {
        A6 = a6;
    }

    public String getA6() {
        return A6;
    }

    public String getSubject() {
        return subject;
    }

    public String getA1() {
        return A1;
    }

    public String getA2() {
        return A2;
    }

    public String getA3() {
        return A3;
    }

    public String getA4() {
        return A4;
    }

    public String getA5() {
        return A5;
    }


    public void setA1(String a1) {
        A1 = a1;
    }

    public void setA2(String a2) {
        A2 = a2;
    }

    public void setA3(String a3) {
        A3 = a3;
    }

    public void setA4(String a4) {
        A4 = a4;
    }

    public void setA5(String a5) {
        A5 = a5;
    }

    public String toString()
    {
        return A1;
    }

}
