package com.example.akshay.miniproject;

import android.content.Context;
import android.content.SharedPreferences;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.toolkit.SimpleTableDataAdapter;

/**
 * Created by akshay on 9/10/17.
 */
public class MySQLClient {





    Context c;
    private SimpleTableDataAdapter adapter;


    public MySQLClient(Context c) {
        this.c = c;
    }




    public void retrieve(final TableView tb)
    {
        SharedPreferences shared = c.getSharedPreferences("Miniproject", c.MODE_PRIVATE);

         String roll1 = (shared.getString("roll", ""));

        String url="http://192.168.1.100/mysubmissions.php"+"?rollno="+roll1;

     //   String url="http://192.168.43.125/mysubmissions.php";
        final ArrayList<Spacecraft> spacecrafts=new ArrayList<>();
        AndroidNetworking.get(url).setPriority(Priority.HIGH).build().getAsJSONArray(new JSONArrayRequestListener() {
            @Override
            public void onResponse(JSONArray response) {

                JSONObject jo;
                Spacecraft s;

                for(int i=0;i<response.length();i++)
                {
                    try {
                        jo=response.getJSONObject(i);
                        String k=jo.getString("sub");
                        String A1=jo.getString("A1");
                        String A2=jo.getString("A2");
                        String A3=jo.getString("A3");
                        String A4=jo.getString("A4");
                        String A5=jo.getString("A5");
                        String A6=jo.getString("A6");

                        s=new Spacecraft();
                        s.setSubject(k);
                        s.setA1(A1);
                        s.setA2(A2);
                        s.setA3(A3);
                        s.setA4(A4);
                        s.setA5(A5);
                        s.setA6(A6);

                        spacecrafts.add(s);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    adapter=new SimpleTableDataAdapter(c,new TableHelper(c).returnSpacseProbesArray(spacecrafts));

                    tb.setDataAdapter(adapter);
                }

            }

            @Override
            public void onError(ANError anError) {

            }
        });




    }



}
