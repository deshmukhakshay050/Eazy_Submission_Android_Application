package com.example.akshay.miniproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;



public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder>
{

    private Context context;
    private List<Mydata>mydata;
     String a[];
     String answer[];
    int position1;



    public CustomAdapter(Context context,List<Mydata>mydata)
    {
        this.context=context;
        this.mydata=mydata;
        a=new String[20];

        answer=new String[20];
        for(int i=0;i<=19;i++)
        {
            a[i]="a";
            answer[i]="";

        }
    }

    public int getItemCount() {
       return mydata.size()+1;
    }



    public CustomAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

       View itemView;
        // = LayoutInflater.from(parent.getContext()).inflate(R.layout.crd,parent,false);

        if(viewType == R.layout.crd){
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.crd, parent, false);
        }

        else {
            itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.button, parent, false);
        }

         return new ViewHolder(itemView);
    }


    public void onBindViewHolder(final CustomAdapter.ViewHolder holder, final int position) {


        if(position == mydata.size()) {
            holder.b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int cnt=0;

                    for(int i=1;i<mydata.size();i++)
                    {
                        if(a[i].equals(answer[i])==true)
                        {
                            cnt++;
                        }
                    }
                    String score=String.valueOf(cnt);

                    String url = "http://192.168.1.100/statusupdate.php";
                    SharedPreferences sharedpreferences;

                    sharedpreferences=context.getSharedPreferences("info", Context.MODE_PRIVATE);
                      String  roll =( sharedpreferences.getString("roll", ""));
                    String div=sharedpreferences.getString("division", "")    ;
                    String subject=sharedpreferences.getString("subject", "");
                    String assignmentno=sharedpreferences.getString("assignmentno","");
                     url = url+"?subject="+subject+"&assignmentno="+assignmentno+"&rollno="+roll;




                    url =url+"?subject="+subject+"&assignmentno="+assignmentno+"&rollno="+roll+"&marks="+cnt;
                    StringRequest stringRequest = new StringRequest(url, new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            showJSON1(response);
                        }
                    },
                            new com.android.volley.Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(context,error.getMessage().toString(),Toast.LENGTH_LONG).show();
                                }
                            });

                    com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(context);
                    requestQueue.add(stringRequest);

                   // sharedpreferences=context.getSharedPreferences("info", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("score",score);
                    editor.putString("close","false");
                    editor.putString("akshay","akshay");
                    editor.putString("clicked","true");
                    editor.commit();
                    editor.commit();

                    Intent intent = new Intent(context, score.class);
                    context.startActivity(intent);

                }
            });
        }
        else {
            holder.question.setText(mydata.get(position).getQuestions());
            holder.option1.setText(mydata.get(position).getA());
            holder.option2.setText(mydata.get(position).getB());
            holder.option3.setText(mydata.get(position).getC());
            holder.option4.setText(mydata.get(position).getD());


            position1 = position;

            holder.r1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("WebView", "your current url when webpage loading.." + "you clicked r1");

                    position1 = position;
                    a[position1 + 1] = holder.option1.getText().toString();
                    answer[position1 + 1] = mydata.get(position1).getAns();
                    Log.d("WebView", "your current url when webpage loading.." + a[position1 + 1] + " " + position + "" + position1 + "" + a);
                    holder.r2.setChecked(false);
                    holder.r3.setChecked(false);
                    holder.r4.setChecked(false);
                }
            });

            holder.r2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("WebView", "your current url when webpage loading.." + "you clicked r2");


                    position1 = position;
                    a[position1 + 1] = holder.option2.getText().toString();
                    answer[position1 + 1] = mydata.get(position1).getAns();
                    Log.d("WebView", "your current url when webpage loading.." + a[position1 + 1] + " " + position + " " + position1 + "" + a);
                    holder.r1.setChecked(false);
                    holder.r3.setChecked(false);
                    holder.r4.setChecked(false);
                }
            });

            holder.r3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("WebView", "your current url when webpage loading.." + "you clicked r3");

                    position1 = position;
                    a[position1 + 1] = holder.option3.getText().toString();
                    answer[position1 + 1] = mydata.get(position1).getAns();
                    Log.d("WebView", "your current url when webpage loading.." + a[position1 + 1] + " " + position + " " + position1 + "" + a);
                    holder.r2.setChecked(false);
                    holder.r1.setChecked(false);
                    holder.r4.setChecked(false);
                }
            });

            holder.r4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("WebView", "your current url when webpage loading.." + "you clicked r4");

                    position1 = position;
                    a[position1 + 1] = holder.option4.getText().toString();
                    answer[position1 + 1] = mydata.get(position1).getAns();
                    Log.d("WebView", "your current url when webpage loading.." + a[position1 + 1] + " " + position + "" + position1 + " " + a);
                    holder.r2.setChecked(false);
                    holder.r3.setChecked(false);
                    holder.r1.setChecked(false);
                }
            });
        }
    }


    private void showJSON1(String response){

      /*  try {
            JSONObject jsonObject = new JSONObject(response);
           // JSONArray result = jsonObject.getJSONArray("result");
            //JSONObject collegeData = result.getJSONObject(0);
            //output=collegeData.getString("output");
        } catch (JSONException e) {

            e.printStackTrace();
        }
*/
    }
    public class ViewHolder extends  RecyclerView.ViewHolder
    {


        public TextView question,option1,option2,option3,option4;
        public Button b;
        public RadioButton r1,r2,r3,r4;

        ItemClickListener itemClickListener;


        public ViewHolder(View itemView) {
            super(itemView);
            question=(TextView)itemView.findViewById(R.id.question);
            option1=(TextView)itemView.findViewById(R.id.option1);

            option2=(TextView)itemView.findViewById(R.id.option2);
            option3=(TextView)itemView.findViewById(R.id.option3);
            option4=(TextView)itemView.findViewById(R.id.option4);
            b=(Button)itemView.findViewById(R.id.load_more);



            r1=(RadioButton)itemView.findViewById(R.id.A);
            r2=(RadioButton)itemView.findViewById(R.id.B);
            r3=(RadioButton)itemView.findViewById(R.id.C);
            r4=(RadioButton)itemView.findViewById(R.id.D);

           // r1.setOnCheckedChangeListener(changeChecker);
            //r2.setOnCheckedChangeListener(changeChecker);
            //r3.setOnCheckedChangeListener(changeChecker);
            //r4.setOnCheckedChangeListener(changeChecker);



        }

        CompoundButton.OnCheckedChangeListener changeChecker = new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    if (buttonView ==r1) {
                        r2.setChecked(false);
                        r3.setChecked(false);
                        r4.setChecked(false);
                    }
                    if (buttonView == r2) {
                        r1.setChecked(false);
                        r3.setChecked(false);
                        r4.setChecked(false);
                    }
                    if (buttonView == r3) {
                        r2.setChecked(false);
                        r1.setChecked(false);
                        r4.setChecked(false);
                    }
                    if (buttonView == r4) {
                        r2.setChecked(false);
                        r3.setChecked(false);
                        r1.setChecked(false);
                    }
                }
            }
        };

        public void setItemClickListener(ItemClickListener itemClickListener)
        {
            this.itemClickListener=itemClickListener;
        }




    }
    public int getItemViewType(int position) {
        return (position == mydata.size()) ? R.layout.button : R.layout.crd;
    }
    public String[] a()
    {
        return a;
    }
    public String[] ans()
    {
        return answer;
    }

}
