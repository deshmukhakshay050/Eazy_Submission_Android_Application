package com.example.akshay.miniproject;
import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.TextView;

import com.nbsp.materialfilepicker.MaterialFilePicker;
import com.nbsp.materialfilepicker.ui.FilePickerActivity;

import java.io.File;
import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class uploadfile extends AppCompatActivity {

    private Button button;
    SharedPreferences sharedpreferences;
    String roll="";
    String div="";
    String subject="";
    String assignmentno="";

    String address = "http://192.168.1.100/upload.php";
    String url="";

    Toolbar toolbar;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uploadfile);




        //navigation drawer part
        NavigationView navigationView=(NavigationView)findViewById(R.id.navigation_view);
        View view=navigationView.inflateHeaderView(R.layout.navigation_drawer_header);


        toolbar=(Toolbar)findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Upload File");
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);


        SharedPreferences shared = getSharedPreferences("info", MODE_PRIVATE);

        String roll = (shared.getString("roll", ""));

        TextView textView1=(TextView)view.findViewById(R.id.textview10);
        textView1.setText(roll);









        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener()
        {

            @Override
            public boolean onNavigationItemSelected(MenuItem item) {

                Intent intent;
                switch (item.getItemId()) {

                    case R.id.subjects: {
                        intent=new Intent(uploadfile.this,SignInInfo.class);
                        // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        //finish(); // destroy current activity..
                        startActivity(intent); // starts new activity;
                        break;
                    }
                    case R.id.logout: {
                        SharedPreferences shared = getSharedPreferences("Miniproject", MODE_PRIVATE);

                        String bool=shared.getString("bool","");
                        bool="false";
                        SharedPreferences.Editor editor = shared.edit();
                        editor.putString("bool",bool);
                        editor.commit();
                        intent = new Intent(uploadfile.this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        finish(); // destroy current activity..
                        startActivity(intent); // starts new activity
                        break;
                    }
                    case R.id.assigninfo: {
                        intent = new Intent(uploadfile.this, Mysub.class);
                        startActivity(intent);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        finish(); // destroy current activity..
                        startActivity(intent); // starts new activity;
                        break;

                    }
                    case R.id.settings:
                    {
                    }

                }


                return false;
            }
        });


        ///////////////////////////////////////
        button = (Button) findViewById(R.id.button2);





        sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);
        roll =( sharedpreferences.getString("roll", ""));
        div=sharedpreferences.getString("division", "")    ;
        subject=sharedpreferences.getString("subject", "");
        assignmentno=sharedpreferences.getString("assignmentno","");
        url = address+"?subject="+subject+"&assignmentno="+assignmentno+"&rollno="+roll;





        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
                return;
            }
        }

        enable_button();
    }

    private void enable_button() {

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new MaterialFilePicker()
                        .withActivity(uploadfile.this)
                        .withRequestCode(10)
                        .start();

            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 100 && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
            enable_button();
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
            }
        }
    }

    ProgressDialog progress;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        if (requestCode == 10 && resultCode == RESULT_OK) {

            progress = new ProgressDialog(uploadfile.this);
            progress.setTitle("Uploading");
            progress.setMessage("Please wait...");
            progress.show();

            SharedPreferences shared = getSharedPreferences("Miniproject", MODE_PRIVATE);

            final String roll1 = (shared.getString("roll", ""));

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {

                    File f = new File(data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH));
                    String content_type = getMimeType(f.getPath());

                    String file_path = f.getAbsolutePath();
                    OkHttpClient client = new OkHttpClient();
                    RequestBody file_body = RequestBody.create(MediaType.parse(content_type), f);


                    RequestBody request_body = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM).addFormDataPart("subject",subject).addFormDataPart("assignmentno",assignmentno).addFormDataPart("rollno",roll1)
                            .addFormDataPart("type", content_type)
                            .addFormDataPart("uploaded_file", file_path.substring(file_path.lastIndexOf("/") + 1), file_body).addFormDataPart("filename",file_path.substring(file_path.lastIndexOf("/") + 1))
                            .addFormDataPart("filepath",subject+"/"+roll1+"/"+assignmentno+"/")
                            .build();


                    String s=file_path.substring(file_path.lastIndexOf("/") + 1);

                    Request request = new Request.Builder()
                            .url(address).method("POST", RequestBody.create(null, new byte[0]))
                            .post(request_body)
                            .build();

                    try {
                        Response response = client.newCall(request).execute();

                        if (!response.isSuccessful()) {
                            throw new IOException("Error : " + response);
                        }

                        progress.dismiss();
                        Intent intent=new Intent(uploadfile.this,questions_mainactivity.class);

                        startActivity(intent);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                }
            });

            t.start();



        }
    }
    protected void onPostCreate(Bundle savesInstanceState)              /////for hamburger iconnnnnnnnnnnnnnn of navigation drawer
    {
        super.onPostCreate(savesInstanceState);
        actionBarDrawerToggle.syncState();

    }
    private String getMimeType(String path) {

        String extension = MimeTypeMap.getFileExtensionFromUrl(path);

        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
    }
}