package com.example.akshay.miniproject;

/**
 * Created by akshay on 24/9/17.
 */
public class Mydata
{

    private String questions,a,b,c,d,ans;

    public Mydata(String questions, String a, String b, String c, String d, String ans) {
        this.questions = questions;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.ans = ans;
    }


    public String getAns() {
        return ans;
    }

    public String getQuestions() {

        return questions;
    }

    public String getA() {
        return a;
    }

    public String getB() {
        return b;
    }

    public String getC() {
        return c;
    }

    public String getD() {
        return d;
    }


    public void setQuestions(String questions) {
        this.questions = questions;
    }

    public void setA(String a) {
        this.a = a;
    }

    public void setB(String b) {
        this.b = b;
    }

    public void setC(String c) {
        this.c = c;
    }

    public void setD(String d) {
        this.d = d;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }
}
