package com.example.akshay.miniproject;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.SyncStateContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.List;

public class splashscreen extends AppCompatActivity {

    TextView tv;
    ImageView img;
   // TextView tb;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);

        SharedPreferences sharedpreferences;
        sharedpreferences=getSharedPreferences("info", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        String close=sharedpreferences.getString("close","");


        if(close.equals("true")==true)
        {

        }
        else
        {

        }


        close=sharedpreferences.getString("close","");
        if(close.equals("true")==true)
        {
            Log.w("A" + System.currentTimeMillis(), "on task removed alled");
            Log.w("A" + System.currentTimeMillis(), "B" + 2000);
            String s = sharedpreferences.getString("score", "");

            String url = "http://192.168.1.100/statusupdate.php";

            sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);
            String roll = (sharedpreferences.getString("roll", ""));
            String div = sharedpreferences.getString("division", "");
            String subject = sharedpreferences.getString("subject", "");
            String assignmentno = sharedpreferences.getString("assignmentno", "");
            editor.putString("close","false");
            editor.commit();
            url = url + "?subject=" + subject + "&assignmentno=" + assignmentno + "&rollno=" + roll;


            Toast.makeText(splashscreen.this, "Your score was:- " + s, Toast.LENGTH_LONG).show();
            url = url + "?subject=" + subject + "&assignmentno=" + assignmentno + "&rollno=" + roll + "&marks=" + s;
            StringRequest stringRequest = new StringRequest(url, new com.android.volley.Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    // showJSON1(response);
                }
            },
                    new com.android.volley.Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(splashscreen.this, error.getMessage().toString(), Toast.LENGTH_LONG).show();
                        }
                    });

            RequestQueue requestQueue = Volley.newRequestQueue(splashscreen.this);
            requestQueue.add(stringRequest);


        }

        tv=(TextView)findViewById(R.id.t);
      //  tb=(TextView)findViewById(R.id.p);
        img=(ImageView)findViewById(R.id.img);
        Animation animation= AnimationUtils.loadAnimation(this,R.anim.transitionanimation);
        tv.startAnimation(animation);
      //  tb.startAnimation(animation);
        img.startAnimation(animation);
       final Intent i=new Intent(this,MainActivity.class);
        Thread timer=new Thread(){
            public void run()
            {
                try {
                    sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {
                    startActivity(i);
                    finish();
                }
            }
        };
                timer.start();
    }

}
