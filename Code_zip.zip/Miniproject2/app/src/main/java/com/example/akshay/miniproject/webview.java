package com.example.akshay.miniproject;


import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.RequestQueue;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.util.Config;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Scroller;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;


public class webview extends AppCompatActivity {

    String ip="http://192.168.1.100";

    String address = ip+"/testcases.php";
    String address1 = ip+"/output.php";
    String address2 = ip+"/try.php";


    WebView mWebView;
    private ValueCallback<Uri> mUploadMessage;
    public ValueCallback<Uri[]> uploadMessage;
    public static final int REQUEST_SELECT_FILE = 100;
    private final static int FILECHOOSER_RESULTCODE = 1;
    String line = null;
    String[] data;
    String result = null;
    InputStream is = null;
    TextView t;
    TextView t1;
    EditText e3;

    String s1="";
    String finished="";
    public  final String DATA_URL =ip+"/testcases.php";
    String testcase="";
    String output="";



    String roll="";                     //for http client
    String div="";
    String subject="";
    String assignmentno="";


    Toolbar toolbar;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    SharedPreferences sharedpreferences;




    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aditya_webview);



        ///testacses edit text3




        ///shared preferences start/--------------------------


        sharedpreferences = getSharedPreferences("info", Context.MODE_PRIVATE);
        roll =( sharedpreferences.getString("roll", ""));
        div=sharedpreferences.getString("division", "")    ;
        subject=sharedpreferences.getString("subject", "");
        assignmentno=sharedpreferences.getString("assignmentno","");




        //Navigation darwer part

        NavigationView navigationView=(NavigationView)findViewById(R.id.navigation_view);
        View view=navigationView.inflateHeaderView(R.layout.navigation_drawer_header);


        toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Compiler");
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);


        TextView textView1=(TextView)view.findViewById(R.id.textview10);
        textView1.setText(roll);






        //-----------------navigation part end///////////////






      //  t = (TextView) findViewById(R.id.webviewtextview);


        mWebView = (WebView) findViewById(R.id.webView);
        WebSettings mWebSettings = mWebView.getSettings();
        mWebSettings.setJavaScriptEnabled(true);
        mWebSettings.setSupportZoom(false);
        mWebSettings.setAllowFileAccess(true);
        mWebSettings.setAllowFileAccess(true);
        mWebSettings.setAllowContentAccess(true);
        mWebView = (WebView) findViewById(R.id.webView);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setLoadsImagesAutomatically(true);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.getSettings().setSaveFormData(true);
        mWebView.getSettings().setAllowContentAccess(true);
        mWebView.getSettings().setAllowFileAccess(true);
        mWebView.getSettings().setAllowFileAccessFromFileURLs(true);
        mWebView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        mWebView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        mWebView.getSettings().setAppCacheEnabled(true);
        mWebSettings.setDomStorageEnabled(true);
        mWebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        mWebSettings.setUseWideViewPort(true);
        mWebView.getSettings().setSupportZoom(true);
        mWebSettings.setSaveFormData(true);
        mWebView.setWebViewClient(new WebViewClient());
        mWebSettings.setEnableSmoothTransition(true);
        mWebView.setClickable(true);

        t1=(TextView)findViewById(R.id.textView2);


        String url=ip+"/mini1/testcases.php";
        url = url+"?subject="+subject+"&assignmentno="+assignmentno+"&rollno="+roll;

        mWebView.loadUrl(url);


        mWebView.setWebChromeClient(new WebChromeClient() {


            // For 3.0+ Devices (Start)
            // onActivityResult attached before constructor
            protected void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {

                //Rest of the co
                mUploadMessage = uploadMsg;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "File Browser"), FILECHOOSER_RESULTCODE);
            }


            // For Lollipop 5.0+ Devices
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {

                //Rest of the co
             /*   if (uploadMessage != null) {
                    uploadMessage.onReceiveValue(null);
                    uploadMessage = null;
                }
*/
                uploadMessage = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                intent.setType("*/*");
                try {
                    startActivityForResult(intent, REQUEST_SELECT_FILE);


                } catch (ActivityNotFoundException e) {
                    uploadMessage = null;
                    //       Toast.makeText(getActivity().getApplicationContext(), "Cannot Open File Chooser", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }

            //For Android 4.1 only
            protected void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {

                //Rest of the co
                mUploadMessage = uploadMsg;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "File Browser"), FILECHOOSER_RESULTCODE);
            }

            protected void openFileChooser(ValueCallback<Uri> uploadMsg) {

                //Rest of the co
                mUploadMessage = uploadMsg;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "File Chooser"), FILECHOOSER_RESULTCODE);
            }
        });


        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                finished=url;
                super.onPageFinished(view, url);
                Log.d("WebView", "your current url when webpage loading.." + url);

            }
        });
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);


                Log.d("WebView", "your current url when webpage loading.." + url);
            }




            @Override
            public void onLoadResource(WebView view, String url) {
                // TODO Auto-generated method stub
                super.onLoadResource(view, url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.d("WebView", "your current url when webpage loading.." + url);
                return super.shouldOverrideUrlLoading(view, url);

            }
        });
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitNetwork().build());
        try {
            getdata();
        } catch (IOException e) {
            e.printStackTrace();
        }

        getoutput();



        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener()
        {

            @Override
            public boolean onNavigationItemSelected(MenuItem item) {

                Intent intent;
                switch (item.getItemId()) {

                    case R.id.subjects: {
                        intent=new Intent(webview.this,SignInInfo.class);
                        // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        //finish(); // destroy current activity..
                        startActivity(intent); // starts new activity;
                        break;
                    }
                    case R.id.logout: {
                        SharedPreferences shared = getSharedPreferences("Miniproject", MODE_PRIVATE);

                        String bool=shared.getString("bool","");
                        bool="false";
                        SharedPreferences.Editor editor = shared.edit();
                        editor.putString("bool",bool);
                        editor.commit();



                        intent = new Intent(webview.this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        finish(); // destroy current activity..
                        startActivity(intent); // starts new activity
                        break;
                    }
                    case R.id.assigninfo: {
                        intent = new Intent(webview.this, Mysub.class);
                        startActivity(intent);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK); // clears all previous activities task
                        finish(); // destroy current activity..
                        startActivity(intent); // starts new activity;
                        break;

                    }
                    case R.id.settings:
                    {
                    }

                }


                return false;
            }
        });

    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (requestCode == REQUEST_SELECT_FILE) {

                uploadMessage.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, intent));
                uploadMessage = null;

            }
        } else if (requestCode == FILECHOOSER_RESULTCODE) {
            if (null == mUploadMessage)
                return;
            // Use MainActivity.RESULT_OK if you're implementing WebView inside Fragment
            // Use RESULT_OK only if you're implementing WebView inside an Activity
            Uri result = intent == null || resultCode !=


                    RESULT_OK ? null : intent.getData();
            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        } else
            Toast.makeText(this.getApplicationContext(), "Failed to Upload", Toast.LENGTH_LONG).show();
    }




    protected void onPostCreate(Bundle savesInstanceState)              /////for hamburger iconnnnnnnnnnnnnnn of navigation drawer
    {
        super.onPostCreate(savesInstanceState);
        actionBarDrawerToggle.syncState();

    }

    public void getdata() throws IOException {

        String url = address+"?subject="+subject+"&assignmentno="+assignmentno;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                showJSON(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(webview.this,error.getMessage().toString(),Toast.LENGTH_LONG).show();
                    }
                });

        com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    private void showJSON(String response){

        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray result = jsonObject.getJSONArray("result");
            JSONObject collegeData = result.getJSONObject(0);
            testcase=collegeData.getString("testacases");
            t.setText(testcase);
        } catch (JSONException e) {

            e.printStackTrace();
        }

    }

    public void clicked(View view) {
        getuseroutput();
        check(s1,output);

    }
    public void getoutput()
    {
        String url = address1+"?subject="+subject+"&assignmentno="+assignmentno;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                showJSON1(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(webview.this,error.getMessage().toString(),Toast.LENGTH_LONG).show();
                    }
                });

        com.android.volley.RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    private void showJSON1(String response){

        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray result = jsonObject.getJSONArray("result");
            JSONObject collegeData = result.getJSONObject(0);
            output=collegeData.getString("output");
        } catch (JSONException e) {

            e.printStackTrace();
        }

    }
    public void check(String s1,String s2)
    {
        if(s1.equals(s2))
        {
            Toast.makeText(getApplicationContext(),"Congrats!!! Your output matched!! Your code is submitted",Toast.LENGTH_LONG).show();
            Intent i=new Intent(webview.this,uploadfile.class);
            startActivity(i);
        }
        else
        {

            Toast.makeText(getApplicationContext(),"Ooopss!! Your Output didnot match to our standard output try again!!",Toast.LENGTH_LONG
            ).show();
        }

    }


    public void onBackPressed()
    {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Do you want to make one more attempt??");
        alertDialogBuilder.setPositiveButton("yes",
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        Intent i=new Intent(webview.this,webview.class);
                        startActivity(i);
                    }
                });

        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {

                Intent i=new Intent(webview.this,SignInInfo.class);
                startActivity(i);
                finish();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();


    }

    public void getuseroutput()
    {
        try {
            URL url = new URL(address2);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            is = new BufferedInputStream(con.getInputStream());

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {

            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        s1="";
        try {

            JSONArray js = new JSONArray(result);
            JSONObject jo = null;
            data = new String[js.length()];
            data[0] = "";
            for (int i = 0; i < js.length(); i++) {
                jo = js.getJSONObject(i);
                data[i] = jo.getString("output");
                s1 = s1+ data[i];
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

    }


}
