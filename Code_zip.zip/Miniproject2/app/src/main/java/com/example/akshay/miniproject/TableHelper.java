package com.example.akshay.miniproject;

import android.content.Context;

import java.util.ArrayList;

/**
 * Created by akshay on 9/10/17.
 */
public class TableHelper
{

    Context c;
    public String[] spaceProbeHeaders={"subject","A1","A2","A3","A4","A5","A6"};
    private String[][] spaceProbes;

    public TableHelper(Context c) {
        this.c = c;
    }
    public String[] getSpaceProbeHeaders()
    {
        return spaceProbeHeaders;
    }
    public String[][] returnSpacseProbesArray(ArrayList<Spacecraft>spacecrafts)
    {
        spaceProbes=new String[spacecrafts.size()][8];
        Spacecraft s;
        for(int i=0;i<spacecrafts.size();i++)
        {
            s=spacecrafts.get(i);
            spaceProbes[i][0]=s.getSubject();
            spaceProbes[i][1]=s.getA1();
            spaceProbes[i][2]=s.getA2();
            spaceProbes[i][3]=s.getA3();
            spaceProbes[i][4]=s.getA4();
            spaceProbes[i][5]=s.getA5();
            spaceProbes[i][6]=s.getA6();

        }
        return spaceProbes;

    }

}
