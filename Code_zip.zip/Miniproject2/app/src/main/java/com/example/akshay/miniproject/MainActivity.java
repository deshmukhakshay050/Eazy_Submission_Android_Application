package com.example.akshay.miniproject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    EditText e1;
    EditText e2;
    Button b;
    ProgressDialog progress;
    SharedPreferences sharedpreferences;
    SharedPreferences sharedpreferences1;


    @Override
    protected void onStart() {
        super.onStart();
        sharedpreferences1 = getSharedPreferences("Miniproject", Context.MODE_PRIVATE);
        String bool=sharedpreferences1.getString("bool","");
        if(bool.equals("true")==true)
        {
            Intent intent = new Intent(MainActivity.this, SignInInfo.class);
            startActivity(intent);

        }
        else if(bool.equals("close")==true)
        {
            SharedPreferences.Editor editor = sharedpreferences1.edit();
            editor.putString("bool","true");
            editor.commit();
            finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        e1=(EditText)findViewById(R.id.editText);
        e2=(EditText)findViewById(R.id.editText2);
        b=(Button)findViewById(R.id.button) ;
        progress=new ProgressDialog(MainActivity.this,ProgressDialog.THEME_HOLO_DARK);

    }
    public void clicked(View view)
    {
        String roll=e1.getText().toString();
        String method="login";
        String pass=e2.getText().toString();
        Background b=new Background(this);
        b.execute(method,roll,pass);

    }
    public void onBackPressed()
    {
        finish();
    }
    class Background extends AsyncTask<String,String,String>
    {
        Context ctx;
        AlertDialog d;
        public Background(Context ctx) {
            this.ctx = ctx;
        }
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            progress.setProgress(Integer.parseInt(values[0]));
        }
        @Override
        protected void onPreExecute() {
            // d=new AlertDialog.Builder(ctx).create();
            //d.setTitle("Login Information...");
            super.onPreExecute();
            progress.setMax(100);
            progress.setTitle("Logging In...");
            progress.setMessage("Just a Moment...");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.show();
            progress.setCanceledOnTouchOutside(false);
        }
        protected void onPostExecute(String  resultd) {

            progress.dismiss();
            resultd=resultd.replaceAll("\\s+","");
            if (resultd.equals("success")==true) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("bool","true");
                editor.commit();
                Intent intent = new Intent(ctx,SignInInfo.class);
                startActivity(intent);
            }
            else
            {
                Toast.makeText(
                        MainActivity.this,
                        "Login Failed:Check for Valid Username and Password!",
                        Toast.LENGTH_SHORT
                ).show();
            }


        }
        protected String doInBackground(String... params)
        {
            for(int i=0;i<100;i++)
            {
                publishProgress(String.valueOf(i));
                try
                {
                    Thread.sleep(40);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
            String method=params[0];
            String login_url="http://192.168.1.100/login.php";
            String roll=params[1];
            String pass=params[2];
            String response="";
            final String code = "Miniproject";
            sharedpreferences = getSharedPreferences(code, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putString("roll", roll);
            editor.commit();

            try {
                URL url=new URL(login_url);
                HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream=httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter=new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
                String data= URLEncoder.encode("roll","UTF-8")+"="+URLEncoder.encode(roll,"UTF-8")+"&"+
                        URLEncoder.encode("pass","UTF-8")+"="+URLEncoder.encode(pass,"UTF-8")+"&";
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream=httpURLConnection.getInputStream();
                BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));

                String line="";

                while((line=bufferedReader.readLine())!=null)
                {
                    response=response+line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }
    }
}